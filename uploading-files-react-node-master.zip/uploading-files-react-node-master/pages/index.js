import React from 'react'
import Uploader from '../components/uploader'

class Home extends React.Component {
  render () {
    return (
      <div>
        <Uploader />
      </div>  
    )
  }
}

export default Home
